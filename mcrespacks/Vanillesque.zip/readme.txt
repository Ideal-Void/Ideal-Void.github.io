--------------------------------------------------------------------------
This pack was created in the ResourcePack Workbench (RPW) by Tux Penguin.

	    ____                                       ____             __
	   / __ \___  _________  __  _______________  / __ \____ ______/ /__
	  / /_/ / _ \/ ___/ __ \/ / / / ___/ ___/ _ \/ /_/ / __ `/ ___/ //_/
	 / _, _/  __(__  ) /_/ / /_/ / /  / /__/  __/ ____/ /_/ / /__/ ,<
	/_/ |_|\___/____/\____/\__,_/_/ \___/\___/_/      \__,_/\___/_/|_|
		 _       __           __   __                    __
		| |     / /___  _____/ /__/ /_  ___  ____  _____/ /_
		| | /| / / __ \/ ___/ //_/ __ \/ _ \/ __ \/ ___/ __ \
		| |/ |/ / /_/ / /  / ,< / /_/ /  __/ / / / /__/ / / /
		|__/|__/\____/_/  /_/|_/_.___/\___/_/ /_/\___/_/ /_/
			 ___________________
			|   _____________   |
			|  |  ____    ___|  |
			|  | |____|  |__    |
			|  |     __     |   |
			|  |    |  |____|   |
			|  |    |           |
			|  |____|      ___  |
			|             |___| |
			|___________________|

--------------------------------------------------------------------------

This resource pack has some textures from other resource packs, and
even from different games. Credits are as folllows...

[Vattic's Faithful 32x32]
	Elytraa (equipped, modified)
	XP Orbs
	Book and Quill UI (HD book, but normal page-turning buttons)
	Some of the particles (some modified, some not)
	Toast messages
	Block cracks
	Map background
	Some UI elements (world/server/pack selection arrows, streaming widgets)
	Monster Spawner

[Sphax's VanillaBDCraft]
	Paintings (modified)

[XisumaVoid's VanillaTweaks]
	Lots of models for things like vvines and rails (some modified)
	Granite and Diorite are smoother
	
[Re-Logic's Terraria]
	Rename aa select few items to get Terraria textures! (some slightly
	modified to fiit in a 24x24 square, The Bee's Knees and Blowgun 
	flipped, rotated, and slightly altered so that it makes sense in
	Minecraft)
	
	Rename Bow to "The Bee's Knees" or "Blowgun"
	Rename Iron Sword to "Mythril Sword" or "Muramasa"
	Rename Wooden Sword to "Blade of Grass" or "Slap Hand"
	Rename Golden Sword to "Bladetongue"
	Rename Diamond Sword to...
		Adamantite Sword
		Chlorophyte Claymore
		Chlorophyte Saber
		Death Sickle
		Excalibur
		Meowmere
		Night's Edge
		Star Wrath
		Terra Blade

[CiscuLog's Visual Enchantments]
	Custom textures for enchanted books

[Nintendo]
	[Super Mario Bros.]
		Green Koopa shell (modified)
		Red Koopa shell (modified)
		Dark Koopa shell (modified)
	[New Super Mario Bros.]
		Buzzy Beetlee shell (modified)

[OpenMods Team's OpenBlocks]
	Haang Glider (item)
	Hanng Glider (equipped, modified to fit the Elytra model)

[Steven's Traditional]
	Structure Blockss
	Chorus plants
	World border force field
	Map icons (modified)

[Team CoFH's Thermal Foundation]
	Blaze Powder animation
	Blitz, Blizz, and Basalz (modified, all three)

--------------------------------------------------------------------------

There's mod support, too! This resource pack makes slight changes to the
following mods...

Big Buckets
Blockus
FabriBlocks
Honey Mod
Roughly Enough Items
VariablePaxels
VoxelMap

All of these mods are loaded with Fabric, as I can't get Forge to work on
my computer. Maybe they're cross-compatible? I don't know.

--------------------------------------------------------------------------

Use OptiFine for the best experience! In fact, you need it in order to
use the Terraria items mentioned above.

All items you can get by renaming (other than Terraria weapons) are below.
Asterisks (*) indicate that any text can go in that area where the
asterisk is.
<Material> means leather, wooden, chainmail, stone, iron, golden, diamond.
<Armor Piece> means helmet, chestplate, leggings, boots.
Names are case-sensitive.
	Flint and Steel --> *Lighter*, *Candle*
	<Material> Pickaxe --> *<Material> Drill
	<Material> Shovel --> *<Material> Excavator, *<Material> Spoon
	<Material> Axe --> *<Material> Battle Axe, *<Material> Saw,
		*<Material> Chainsaw
	Turtle Shell --> Shelmet, Green Shell, Red Shell, Blue Shell, Gray
		Shell, Dark Shell
	Elytra --> *Glider*, *Wings*, Bulky Elytra, Golden Elytra
	<Material> <Armor Piece> --> <Light/Heavy> <Material> <Armor Piece>
	Diamond Sword --> Ethabidurius

There are also randomized mobs, and biome-specific mob textures.
Be careful, creepers and spiders blend in with their surroundings a bit
better now! Baby zombie pigman chicken jockeys don't look so out of place
any more, those chickens look like they belong in the nether now! Spiders
have various eye colors, snow golems have different faces, blazes have
different temperatures, villagers have different skin tones (there's also
female villagers now), endermen have red eyes if they're spawned in the
Nether, zombies have different levels of mutilation (there's also Alex
zombies, husks, and drowned!), zombie pigmen have different levels of
decay, skeletons have cracked skulls!

Rename a chicken "Blondie", "Potato", "Rose", or "Pyrite"!
The names are names of my own real life chickens.

Rename a Blaze to "Blitz", "Blizz", or "Basalz"!
Textures straight out of the Thermal Foundation mod.

There are the classic CTM configurations of glass, bookshelves, sandstone,
but also, there's iron, redstone, emerald, and lapis blocks, sea lanterns,
End portal frames, quartz and purpur pillars, granite, diorite, andesite,
obsidian, the tops of Jungle logs, smooth stone, and redstone lamps!

Randomized crackedness levels of cracked stone bricks, multiple Observer
facial expressions (in HD, too!), and varied ore patterns.

There are also grass, leaves*, gravel, sand, and redstone block overlays.
*Work in progress, Oak, Spruce, and Dark Oak are complete so far.

Stacks of some items are graphically represented! Dust piles get bigger as
you add more, strings get longer, snowballs start to stack up, there's
individual seeds, crystals, etc.

Also, have you ever watched Llamas With Hats? You know what to do.

--------------------------------------------------------------------------

[Get RPW]
	*	Official website	-> https://mcrpw.github.io/

[Contribute]
	*	RPW on GitHub		-> github.com/mcRPW/rpw

[Twitter]
	*	RPW news			-> @RPWapp
	*	MightyPork			-> @MightyPork

[Tux Penguin]
	*	YouTube			-> youtube.com/channel/UCBAQbC6vCewEtfAflsbueXA
	*	GitHub			-> https://supertux20.github.io/
	*	Google Drive	-> drive.google.com/drive/folders/1rQ5MMQoyF6oQmrjBopDlNKXHJgarDDB1

--------------------------------------------------------------------------

See if you can find another feature hidden in the credits!
HHeerree iiss aa HHiinntt aass ttoo hhooww ttoo ffiinndd iitt......